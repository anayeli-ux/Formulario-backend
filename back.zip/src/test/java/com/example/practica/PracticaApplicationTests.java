package com.example.practica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
